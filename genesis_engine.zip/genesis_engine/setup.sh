#!/data/data/com.termux/files/usr/bin/bash
set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${GREEN}[✓] $1${NC}"; }
warn() { echo -e "${YELLOW}[!] $1${NC}"; }
fail() { echo -e "${RED}[✗] $1${NC}"; exit 1; }

echo ""
echo "╔══════════════════════════════════╗"
echo "║        JARVIS SETUP v1.0         ║"
echo "╚══════════════════════════════════╝"
echo ""

# ── Базовые пакеты ────────────────────────────────────────────────────────────
log "Обновляю пакеты..."
pkg update -y && pkg upgrade -y

log "Устанавливаю базовые пакеты..."
pkg install -y \
    python \
    python-pip \
    clang \
    cmake \
    make \
    ninja \
    fftw \
    git \
    curl \
    wget \
    termux-api \
    ffmpeg \
    libopenblas

# ── Определяем архитектуру ────────────────────────────────────────────────────
ARCH=$(uname -m)
log "Архитектура: $ARCH"

# ── Определяем RAM ────────────────────────────────────────────────────────────
RAM_KB=$(grep MemAvailable /proc/meminfo | awk '{print $2}')
RAM_GB=$(echo "scale=1; $RAM_KB / 1024 / 1024" | bc)
log "Доступная RAM: ${RAM_GB} GB"

# ── Выбираем модель ───────────────────────────────────────────────────────────
if (( $(echo "$RAM_GB < 4" | bc -l) )); then
    MODEL_NAME="tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf"
    MODEL_URL="https://huggingface.co/TheBloke/TinyLlama-1.1B-Chat-v1.0-GGUF/resolve/main/tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf"
    MODEL_SIZE="~700 MB"
elif (( $(echo "$RAM_GB < 8" | bc -l) )); then
    MODEL_NAME="mistral-7b-instruct-v0.2.Q4_K_M.gguf"
    MODEL_URL="https://huggingface.co/TheBloke/Mistral-7B-Instruct-v0.2-GGUF/resolve/main/mistral-7b-instruct-v0.2.Q4_K_M.gguf"
    MODEL_SIZE="~4.4 GB"
else
    MODEL_NAME="Meta-Llama-3-8B-Instruct.Q4_K_M.gguf"
    MODEL_URL="https://huggingface.co/QuantFactory/Meta-Llama-3-8B-Instruct-GGUF/resolve/main/Meta-Llama-3-8B-Instruct.Q4_K_M.gguf"
    MODEL_SIZE="~4.9 GB"
fi

log "Выбранная модель: $MODEL_NAME ($MODEL_SIZE)"

# ── Python зависимости ────────────────────────────────────────────────────────
log "Устанавливаю Python зависимости..."
pip install --upgrade pip

pip install \
    aiogram \
    psutil \
    requests \
    yt-dlp \
    edge-tts \
    python-dotenv

# ── Компиляция llama-cpp-python ───────────────────────────────────────────────
log "Компилирую llama-cpp-python (это займёт 10-20 минут)..."

export CMAKE_ARGS="-DLLAMA_BLAS=ON -DLLAMA_BLAS_VENDOR=OpenBLAS"
export FORCE_CMAKE=1

if [[ "$ARCH" == "aarch64" ]]; then
    warn "ARM64 — добавляю NEON оптимизации"
    export CMAKE_ARGS="$CMAKE_ARGS -DLLAMA_NATIVE=ON"
fi

pip install llama-cpp-python --no-cache-dir && log "llama-cpp-python установлен!" || fail "Ошибка компиляции llama-cpp-python"

# ── Скачиваем модель ──────────────────────────────────────────────────────────
MODEL_DIR="$HOME/jarvis_models"
mkdir -p "$MODEL_DIR"

MODEL_PATH="$MODEL_DIR/$MODEL_NAME"

if [ -f "$MODEL_PATH" ]; then
    warn "Модель уже скачана: $MODEL_PATH"
else
    log "Скачиваю модель $MODEL_NAME ($MODEL_SIZE)..."
    warn "Не отключай интернет и не закрывай Termux!"
    curl -L --progress-bar -o "$MODEL_PATH" "$MODEL_URL" || fail "Ошибка скачивания модели"
    log "Модель скачана: $MODEL_PATH"
fi

# ── Создаём .env ──────────────────────────────────────────────────────────────
JARVIS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$JARVIS_DIR/.env"

if [ ! -f "$ENV_FILE" ]; then
    log "Создаю .env файл..."
    echo "" > "$ENV_FILE"
    echo "# Jarvis Configuration" >> "$ENV_FILE"
    echo "JARVIS_BOT_TOKEN=your_telegram_bot_token_here" >> "$ENV_FILE"
    echo "JARVIS_OWNER_ID=your_telegram_user_id_here" >> "$ENV_FILE"
    echo "JARVIS_MODEL_DIR=$MODEL_DIR" >> "$ENV_FILE"
    echo "JARVIS_DOWNLOAD_DIR=$HOME/jarvis_downloads" >> "$ENV_FILE"
    echo "JARVIS_SCRIPTS_DIR=$HOME/jarvis_scripts" >> "$ENV_FILE"
    warn "Заполни .env файл: nano $ENV_FILE"
else
    warn ".env уже существует, пропускаю"
fi

# ── Автозапуск ────────────────────────────────────────────────────────────────
BOOT_DIR="$HOME/.termux/boot"
mkdir -p "$BOOT_DIR"

cat > "$BOOT_DIR/jarvis.sh" << EOF
#!/data/data/com.termux/files/usr/bin/bash
source $JARVIS_DIR/.env
export JARVIS_BOT_TOKEN=\$JARVIS_BOT_TOKEN
export JARVIS_OWNER_ID=\$JARVIS_OWNER_ID
export JARVIS_MODEL_DIR=\$JARVIS_MODEL_DIR
export JARVIS_DOWNLOAD_DIR=\$JARVIS_DOWNLOAD_DIR
export JARVIS_SCRIPTS_DIR=\$JARVIS_SCRIPTS_DIR
cd $JARVIS_DIR
python bot.py >> $HOME/jarvis.log 2>&1 &
EOF

chmod +x "$BOOT_DIR/jarvis.sh"
log "Автозапуск настроен (нужно приложение Termux:Boot)"

# ── Создаём директории ────────────────────────────────────────────────────────
mkdir -p "$HOME/jarvis_downloads" "$HOME/jarvis_scripts"

# ── Готово ────────────────────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║              УСТАНОВКА ЗАВЕРШЕНА!                ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""
log "Шаг 1: Заполни токен бота в .env:"
echo "         nano $ENV_FILE"
echo ""
log "Шаг 2: Узнай свой Telegram ID — напиши @userinfobot"
echo ""
log "Шаг 3: Запусти Jarvis:"
echo "         cd $JARVIS_DIR && python bot.py"
echo ""
warn "Для автозапуска установи приложение 'Termux:Boot' из F-Droid"
echo ""
